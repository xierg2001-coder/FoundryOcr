using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FoundryOcr;
using Microsoft.Windows.ApplicationModel.DynamicDependency;

namespace FoundryOcr.Cli;

internal static class Program
{
    static async Task<int> Main(string[] args)
    {
        bool useStdin = args.Any(a => a.Equals("--stdin", StringComparison.OrdinalIgnoreCase));
        bool pretty   = args.Any(a => a.Equals("--pretty", StringComparison.OrdinalIgnoreCase));
        bool isBase64 = args.Any(a => a.Equals("--base64", StringComparison.OrdinalIgnoreCase));

        string? pathArg = args.FirstOrDefault(a => !a.StartsWith("--", StringComparison.Ordinal));

        if (!isBase64 && !useStdin && string.IsNullOrWhiteSpace(pathArg))
        {
            PrintUsage();
            return 2;
        }
        if (isBase64 && !useStdin)
        {
            pathArg = GetOptionValue(args, "--base64");
            if (string.IsNullOrWhiteSpace(pathArg))
            {
                Console.Error.WriteLine("Missing base64 string after --base64.");
                return 2;
            }
        }
        if (!string.IsNullOrWhiteSpace(pathArg) && (useStdin && isBase64))
        {
            Console.Error.WriteLine("When using --stdin --base64, do not also pass a file path.");
            return 2;
        }

        try
        {
            Bootstrap.Initialize(0);

            string json;

            if (isBase64)
            {
                string base64;
                if (useStdin)
                {
                    using var reader = new StreamReader(Console.OpenStandardInput(), Encoding.UTF8, true);
                    base64 = await reader.ReadToEndAsync();
                }
                else
                {
                    base64 = pathArg!;
                }

                byte[] bytes = DecodeBase64(base64);
                json = await OcrService.RecognizeAsJsonFromBytesAsync(bytes, indented: pretty);
            }
            else if (useStdin)
            {
                using var stdin = Console.OpenStandardInput();
                json = await OcrService.RecognizeAsJsonFromStreamAsync(stdin, indented: pretty);
            }
            else
            {
                json = await OcrService.RecognizeAsJsonAsync(pathArg!, indented: pretty);
            }

            Console.Out.WriteLine(json);
            return 0;
        }
        catch (FormatException fex)
        {
            Console.Error.WriteLine("Base64 decode failed: " + fex.Message);
            return 3;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex.ToString());
            return 1;
        }
        finally
        {
            try { Bootstrap.Shutdown(); } catch { }
        }
    }

    private static string? GetOptionValue(string[] args, string optionName)
    {
        for (int i = 0; i < args.Length; i++)
        {
            if (args[i].Equals(optionName, StringComparison.OrdinalIgnoreCase))
            {
                if (i + 1 < args.Length && !args[i + 1].StartsWith("--", StringComparison.Ordinal))
                    return args[i + 1];
                return null;
            }
        }
        return null;
    }

    private static byte[] DecodeBase64(string base64)
    {
        if (string.IsNullOrWhiteSpace(base64))
            throw new FormatException("Empty base64 string.");

        base64 = base64.Trim();
        return Convert.FromBase64String(base64);
    }

    private static void PrintUsage()
    {
        Console.Error.WriteLine(
@"Usage:
  FoundryOcr.Cli.exe <imagePath> [--pretty]
  FoundryOcr.Cli.exe --stdin [--pretty]
  FoundryOcr.Cli.exe --base64 <base64String> [--pretty]
  FoundryOcr.Cli.exe --stdin --base64 [--pretty]");
    }
}
